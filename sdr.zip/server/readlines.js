'use strict'
// ----------------------------------------------------------------------------
// Use readlines to read a text file, line per line
// give file name and a function to be called with each line one by one
// at end of file, it ends with a resolve to resume processing 
// use with await...
// example, display "index.js" with line numbers:
/*
    let line_number = 0
    await("./index.js", function (line){
        line_number++
        console.log(line_number, line.slice(0,80))
    })
*/

// ----------------------------------------------------------------------------
const fs        = require('fs')
const readline  = require('readline')
// ----------------------------------------------------------------------------

function
readLines( filename, line_reader){
    return new Promise(function (resolve, reject){
        let fileStream = fs.createReadStream( filename )        
        fileStream.on('error', function (error) {
            reject(error)
        })
        fileStream.on('ready', function () {
            const rl = readline.createInterface( { input: fileStream })
            rl.on('line', line_reader)
        })
        fileStream.on('end', resolve)
    })
}

module.exports = readLines 