'use strict'
// --------------------------------------------------------------------------
/*
look for a 'needle' item in a 'haystack' array.
the cmp(item, needle) function works like for the array.sort function
It returns the 'index' of the item in haystack where 'cmp' matches

If not found, it returns 'index' such as:
    cmp(index, needle) < 0 && cmp(index+1,needle) > 0

*/
// -------------------------------------------------------------------------
function
bsearch( haystack, needle, cmp) {
    let a = 0 
    let b = haystack.length-1

    if ( cmp( haystack[a], needle ) >= 0 ){ 
        return a
    }
    if ( cmp( haystack[b], needle ) <= 0 ){
        return b
    }

    while ( a < b - 5 ) { // Go linear search for the few (5) last comparisons
        let m = ( a + b ) >>> 1         // maybe should do   a+(b-a)/2
        let delta = cmp( haystack[m], needle) 
        if ( delta < 0 ){
            a = m + 1
        } else if ( delta > 0 ){
            b = m - 1
        } else {
            return m
        }
    }
    
    for ( let i = a ; i <= b ; i++)
        if ( cmp(haystack[i], needle) > 0 )
            return i

    console.error("pb fuzzy bsearch, probably unsorted array")
    return -1        
}

module.exports = bsearch