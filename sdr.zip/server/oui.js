'use strict'

const readLines = require("./readlines")
// ----------------------------------------------------------------------------

let DB 

async function
oui(id){
    if (! DB) {
        DB = {}
        await read_db("oui.txt") // from http://standards-oui.ieee.org/oui/oui.txt 
        await read_db("cid.txt") // from http://standards-oui.ieee.org/cid/cid.txt
    }
    id = clean(id)
    return id && DB[id]

    async function
    read_db(file){
        let line_number = 0        // skip the first 3 lines
        let offset = 0
        let info
        let id
        function
        read_one_line(line){
            if ( ++line_number <= 3) 
                return // skip first 3 lines
            if (line === "") {  // organisations are separated by empty lines
                if (id) 
                    DB[ id ] = info
                id = null
                offset = 0
                return
            }
            switch (offset++) {
                case 0: // [ id, info ] = line.split("(hex)")    
                break 
                case 1: [ id, info ] = line.split("(base 16)")
                        id   = clean(id)
                        info = info.trim()
                break
                default: info += "\n" + line.replace(/ +/g, ' ').trim()
                break
            }
        }
        await readLines(file, read_one_line)
    }

}
// ----------------------------------------------------------------------------

function
clean(id){
    if (!id) return null
    id = id.replace(/-/g, '')
    id = id.replace(/:/g, '')
    id = id.slice(0,6)
    return id.toUpperCase()
}

module.exports = oui