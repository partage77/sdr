'use strict'
// ------------------------------------------------------------------------------------------------
module.exports = { filter, filter_transpile }
// ------------------------------------------------------------------------------------------------
function
filter(DB, filter_string){
    let f       = filter_transpile(filter_string)  // compile a filter function. 
                                            // todo, keep a cached of compiled function
                                            // pure linear filter, slow but OK for PoC v1
    return DB.filter(f)
}
// ------------------------------------------------------------------------------------------------
function
filter_transpile(input){
                                            // todo, add hints parmater about fields, so to be safer (only accpet certain fields, but also open the door to:
                                            //  type checking, 
                                            //  complex objects
                                            //  functions
                                            //  unions...
                                            //  maybe also, fast filtering functions (ex for date range)
                                            
    let tokens    = input.split(" ")           // todo, better tokenizer
    let txtptr  = 0
    let f = filter() 
    // if (! f) ...

    return eval( 'o=>' + f)
// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
    function
    filter(){
        let token = tokens[txtptr]
        let res 
        if ( token === '(' ){
            txtptr++
            res = '(' + filter() + ')'
            txtptr++ // for the ')'
        } else {
            res = comparison() 
        }
        for (;;){
            let token = tokens[txtptr]
            switch (token){
                case ',': 
                case 'and': 
                    txtptr++
                    res += ' && ' + filter()
                    break
                case 'or':
                    txtptr++
                    res += ' || ' + filter()
                    break
                default:
                    return res
            }
        }
    }
// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
    function
    comparison(){
        let name  = tokens[txtptr++]
        let op    = tokens[txtptr++]
        let value = tokens[txtptr++]
        switch ( op ){
            case '<' : case '>': case '<=': case '>=': case '==': break
            case '=' : op = '==' ; break
            default : console.error("ooops")
            return 
        }
        return "o." + name + " " + op + " " + value
    }
}


// ------------------------------------------------------------------------------------------------
function
test_filter_compile(){
    let f = filter_compile("toto < 100")
    console.log( f({toto:10}))
    console.log( ! f({toto:120}))

    let g = filter_compile( "glop < 100 and ( x > 1900 , x < 2000 ) and ( y = 'red' or y == 'blue' )")
    console.log( ! g({ glop:  10, x:1958, y:"yellow" }))
    console.log(   g({ glop:  10, x:1958, y:"red"    }))
    console.log( ! g({ glop: 210, x:2021, y:"red"    }))
    console.log( ! g({ glop: 210, x:1000, y:"red"    }))
}

