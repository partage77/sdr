'use strict'
// --------------------------------------------------------------------------

const port      = process.env.PORT       || 8080
const fs        = require('fs')
const express   = require('express')
const app       = express()

const http      = require('http')
const server    = http.createServer(app)
const WebSocket = require('ws')
const { createWebSocketStream } = require('ws')
const wss       = new WebSocket.Server({     
    "server"    : server
})

app.use(express.static(__dirname + '/public'))
app.use(express.json())


let sniffers = []
let sockets = new Set()

app.post('/log', function (req, res) {
  res.send('POST request to the homepage')
  console.log(req.body)

  let address = req.headers['x-forwarded-for'] || req.socket.remoteAddress

  let { name, value } = req.body
  if (name === "start"){
      // log a new session for that sniffer
      sniffers[address] = []
  } else {
    sniffers[address] = sniffers[address] || []
    let log = { name,value, time : Date.now() }
    sniffers[address].push(log)     
    broadcast(log)
    }
})


// --------------------------------------------------------------------------
server.listen(port, () => {
    console.log(`SDR server listening locally on port ${port}`);
    console.log('Press Ctrl+C to quit.');    
})


wss.on( 'connection' , function (socket, request) {    
    console.log("watcher IP:", request.connection.remoteAddress)
    sockets.add(socket)    
    socket.on('close', function () {
    sockets.delete(socket)
  })
})

function
broadcast(message){
    let m = JSON.stringify(message)
    sockets.forEach(s => {
        s.send( m )
    })
}
